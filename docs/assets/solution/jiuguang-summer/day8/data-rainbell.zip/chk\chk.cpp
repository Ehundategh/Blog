#include <algorithm>
#include <cerrno>
#include <climits>
#include <cstdlib>
#include <fstream>
#include <iomanip>
#include <numeric>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <vector>
using namespace std;
struct DSU{
    vector <int> Fa;
    DSU(int n=0){Init(n);}
    void Init(int n){Fa.resize(n+1);iota(Fa.begin(),Fa.end(),0);}
    int Find(int x){return Fa[x]==x?x:Fa[x]=Find(Fa[x]);}
    bool Merge(int x,int y){
        x=Find(x);y=Find(y);
        if(x==y) return false;
        Fa[x]=y;return true;
    }
    int Count(int n){
        int Ret=0;
        for(int i=1;i<=n;i++) if(Find(i)==i) Ret++;
        return Ret;
    }
};
struct edge{
    int St,Ed,Type;
};
double FullScore;
ofstream ScoreFile,InfoFile;
void Finish(double Score,const string &Info){
    ScoreFile<<setprecision(12)<<Score<<"\n";
    InfoFile<<Info<<"\n";
    exit(0);
}
bool GetInt(const string &s,int &x){
    if(s.empty()) return false;
    char *End=nullptr;
    errno=0;
    long long Val=strtoll(s.c_str(),&End,10);
    if(errno||*End||Val<INT_MIN||Val>INT_MAX) return false;
    x=(int)Val;return true;
}
long long Key(int x,int y){
    if(x>y) swap(x,y);
    return (1ll*x<<32)|(unsigned int)y;
}
int main(int argc,char **argv){
    if(argc!=7) return 3;
    ifstream In(argv[1]),Out(argv[2]);
    FullScore=strtod(argv[4],nullptr);
    ScoreFile.open(argv[5]);InfoFile.open(argv[6]);
    if(!In||!Out||!ScoreFile||!InfoFile) return 4;
    int c,T;
    if(!(In>>c>>T)) Finish(0,"Invalid judge input.");
    for(int Case=1;Case<=T;Case++){
        int n,m,k;
        In>>n>>m>>k;
        vector <edge> Edge(m+1);
        unordered_map <long long,int> Type;
        Type.reserve(m*2+1);
        DSU All(n),Zero(n),One(n);
        for(int i=1;i<=m;i++){
            In>>Edge[i].St>>Edge[i].Ed>>Edge[i].Type;
            Type[Key(Edge[i].St,Edge[i].Ed)]|=1<<Edge[i].Type;
            All.Merge(Edge[i].St,Edge[i].Ed);
            if(Edge[i].Type==0) Zero.Merge(Edge[i].St,Edge[i].Ed);
            else One.Merge(Edge[i].St,Edge[i].Ed);
        }
        bool Connected=(All.Count(n)==1);
        int MinZero=One.Count(n)-1;
        int MaxZero=n-Zero.Count(n);
        bool Feasible=Connected&&MinZero<=k&&k<=MaxZero;
        string First;
        if(n==1&&Feasible) continue;
        if(!(Out>>First)) Finish(0,"Case "+to_string(Case)+": output ended early.");
        if(First=="no"){
            string Second;
            if(!(Out>>Second)||Second!="solution")
                Finish(0,"Case "+to_string(Case)+": expected no solution.");
            if(Feasible) Finish(0,"Case "+to_string(Case)+": a valid solution exists.");
            continue;
        }
        if(!Feasible) Finish(0,"Case "+to_string(Case)+": contestant printed edges for an impossible case.");
        DSU Chosen(n);
        unordered_set <long long> Used;
        Used.reserve(max(1,n*2));
        int ZeroCount=0;
        for(int i=1;i<=n-1;i++){
            string Su,Sv,St;
            if(i==1) Su=First;
            else if(!(Out>>Su)) Finish(0,"Case "+to_string(Case)+": not enough edges.");
            if(!(Out>>Sv>>St)) Finish(0,"Case "+to_string(Case)+": incomplete edge.");
            int u,v,t;
            if(!GetInt(Su,u)||!GetInt(Sv,v)||!GetInt(St,t))
                Finish(0,"Case "+to_string(Case)+": edge contains a non-integer token.");
            if(u<1||u>n||v<1||v>n||u==v||t<0||t>1)
                Finish(0,"Case "+to_string(Case)+": edge value is out of range.");
            long long Id=Key(u,v);
            auto It=Type.find(Id);
            if(It==Type.end()||!(It->second&(1<<t)))
                Finish(0,"Case "+to_string(Case)+": edge does not exist in the input.");
            if(!Used.insert(Id).second)
                Finish(0,"Case "+to_string(Case)+": an edge is repeated.");
            if(!Chosen.Merge(u,v))
                Finish(0,"Case "+to_string(Case)+": chosen edges contain a cycle.");
            if(t==0) ZeroCount++;
        }
        if(ZeroCount!=k)
            Finish(0,"Case "+to_string(Case)+": wrong number of type-0 edges.");
        if(Chosen.Count(n)!=1)
            Finish(0,"Case "+to_string(Case)+": chosen edges are disconnected.");
    }
    string Extra;
    if(Out>>Extra) Finish(0,"Extra output after the last test case.");
    Finish(FullScore,"Correct.");
    return 0;
}

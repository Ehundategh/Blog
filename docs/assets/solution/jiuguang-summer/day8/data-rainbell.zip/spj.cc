#include <algorithm>
#include <cerrno>
#include <climits>
#include <cstdlib>
#include <fstream>
#include <numeric>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <vector>
using namespace std;

struct DSU{
    vector <int> Fa;
    DSU(int n=0){Init(n);}
    void Init(int n){Fa.resize(n+1);iota(Fa.begin(),Fa.end(),0);}
    int Find(int x){return Fa[x]==x?x:Fa[x]=Find(Fa[x]);}
    bool Merge(int x,int y){
        x=Find(x);y=Find(y);
        if(x==y) return false;
        Fa[x]=y;
        return true;
    }
    int Count(int n){
        int Ret=0;
        for(int i=1;i<=n;i++) if(Find(i)==i) Ret++;
        return Ret;
    }
};

bool Get_Int(const string &s,int &x){
    if(s.empty()) return false;
    char *End=nullptr;
    errno=0;
    long long Val=strtoll(s.c_str(),&End,10);
    if(errno||*End||Val<INT_MIN||Val>INT_MAX) return false;
    x=(int)Val;
    return true;
}

long long Get_Key(int x,int y){
    if(x>y) swap(x,y);
    return (1ll*x<<32)|(unsigned int)y;
}

int main(int argc,char **argv){
    if(argc!=4) return 1;
    ifstream In(argv[1]),Out(argv[3]);
    if(!In||!Out) return 1;
    int c,T;
    if(!(In>>c>>T)) return 1;
    while(T-->0){
        int n,m,k;
        if(!(In>>n>>m>>k)) return 1;
        unordered_map <long long,int> Type;
        Type.reserve(m*2+1);
        DSU All(n),Zero(n),One(n);
        for(int i=1;i<=m;i++){
            int u,v,t;
            if(!(In>>u>>v>>t)) return 1;
            Type[Get_Key(u,v)]|=1<<t;
            All.Merge(u,v);
            if(t==0) Zero.Merge(u,v);
            else One.Merge(u,v);
        }
        bool Feasible=All.Count(n)==1&&One.Count(n)-1<=k&&k<=n-Zero.Count(n);
        if(n==1&&Feasible) continue;
        string First;
        if(!(Out>>First)) return 1;
        if(First=="no"){
            string Second;
            if(!(Out>>Second)||Second!="solution"||Feasible) return 1;
            continue;
        }
        if(!Feasible) return 1;
        DSU Chosen(n);
        unordered_set <long long> Used;
        Used.reserve(n*2+1);
        int ZeroCount=0;
        for(int i=1;i<=n-1;i++){
            string Su,Sv,St;
            if(i==1) Su=First;
            else if(!(Out>>Su)) return 1;
            if(!(Out>>Sv>>St)) return 1;
            int u,v,t;
            if(!Get_Int(Su,u)||!Get_Int(Sv,v)||!Get_Int(St,t)) return 1;
            if(u<1||u>n||v<1||v>n||u==v||t<0||t>1) return 1;
            long long Id=Get_Key(u,v);
            auto It=Type.find(Id);
            if(It==Type.end()||!(It->second&(1<<t))) return 1;
            if(!Used.insert(Id).second||!Chosen.Merge(u,v)) return 1;
            if(t==0) ZeroCount++;
        }
        if(ZeroCount!=k||Chosen.Count(n)!=1) return 1;
    }
    string Extra;
    if(Out>>Extra) return 1;
    return 0;
}

#include "testlib.h"
#include <cmath>
#include <cstdio>
#include <string>
using namespace std;

int main(int argc,char *argv[]){
    registerTestlibCmd(argc,argv);
    string First=ouf.readLine();
    if(First!="Correct!") quitf(_wa,"the repeated scenes were not located correctly");
    string Second=ouf.readLine(),Third=ouf.readLine();
    int Count=-1;
    double Printed=-1;
    if(sscanf(Second.c_str(),"Max travelers used: %d",&Count)!=1) quitf(_wa,"invalid traveler-count report");
    if(sscanf(Third.c_str(),"Score ratio: %lf%%",&Printed)!=1) quitf(_wa,"invalid score-ratio report");
    ouf.readEof();
    if(Count<0||Count>200) quitf(_wa,"traveler limit exceeded");
    double Percent=Count<=80?100.0:8000.0/Count;
    if(fabs(Printed-Percent)>1e-4) quitf(_wa,"inconsistent score-ratio report");
    quitp(Percent/100.0,"maximum traveler count: %d",Count);
}

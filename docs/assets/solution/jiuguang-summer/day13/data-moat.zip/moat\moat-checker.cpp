#include "testlib.h"
#include <cstdio>
#include <string>
using namespace std;

int main(int argc,char *argv[]){
    registerTestlibCmd(argc,argv);
    string First=ouf.readLine(),Line,Last;
    if(First!="Finished!") quitf(_wa,"invalid interaction report");
    while(!ouf.seekEof()) Last=ouf.readLine();
    double Percent=-1;
    if(sscanf(Last.c_str(),"Score ratio: %lf%%",&Percent)!=1||Percent<0||Percent>100) quitf(_wa,"invalid score-ratio report");
    quitp(Percent/100.0,"outcome score ratio: %.6f%%",Percent);
}

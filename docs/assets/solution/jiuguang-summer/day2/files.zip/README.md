九光暑假第二天 下发文件

statement/day2.pdf         题面
solution/day2-solution.pdf 题解 PDF
std/*.cpp                  参考代码
sample/*                   下发样例

完整数据见博客中的 data-*.zip。